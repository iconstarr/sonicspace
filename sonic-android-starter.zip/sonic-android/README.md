# SONIC Android starter (v0.1)

A real Android Studio project scaffold for the first SONIC milestone: selecting audio files, queueing them, and using AndroidX Media3 `MediaSessionService` so playback can continue in the background with system media controls.

## Open and run
1. Install Android Studio (current stable) and Android SDK 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `sonic-android` folder.
4. Let Gradle sync, then run on an Android phone or emulator (Android 8.0+).
5. Tap **Add music from device**, select audio files, start playback, and lock the screen to test background playback.

## Current status / honest boundaries
- Included: Android project structure, polished dark starter screen, local audio picker, queue, play/pause/previous/next, Media3 playback service.
- Not included yet: online streaming provider integrations, catalog search, persisted likes/playlists, recommendations, production artwork, APK build/signing.
- This is source code, not an installed APK. It has not been compiled or tested on a device in this environment.
- Streaming-source work is a separate milestone because each provider has different API credentials, catalog availability, and playback rules.

## Next milestones
1. Build and test this project on your phone.
2. Add one permitted streaming catalog and verify background playback with real online tracks.
3. Add local persistence for likes, skips, replays, playlists, and listening history.
4. Build the recommendation ranker using language, artist, mood/genre, co-listening, skips, and novelty.
